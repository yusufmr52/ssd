<?php
/**
 * Template Name: Homepage (Custom)
 * Description: Custom homepage template with all sections rendered directly in PHP.
 * No WPBakery required — uses child theme CSS classes.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();
?>

<div class="ssdk-pb-container">

<!-- HERO -->
<section class="ssdk-hero">
  <div class="ssdk-container ssdk-hero-inner">
    <div class="ssdk-hero-text">
      <span class="ssdk-hero-eyebrow"><span class="dot"></span> Starlink is NOW in the UAE &mdash; ask us about satellite connectivity</span>
      <h1>Security systems Dubai businesses <span class="accent">actually rely on</span></h1>
      <p class="ssdk-hero-lead">From CCTV surveillance and access control to wireless infrastructure and meeting room technology &mdash; we design, install and support secure systems across the UAE, with ISO 9001:2015 quality management.</p>
      <div class="ssdk-hero-stats">
        <div class="ssdk-hero-stat"><div class="num">17+</div><div class="lab">Years in the UAE</div></div>
        <div class="ssdk-hero-stat"><div class="num">500+</div><div class="lab">Projects delivered</div></div>
        <div class="ssdk-hero-stat"><div class="num">ISO</div><div class="lab">9001:2015 certified</div></div>
      </div>
      <div class="ssdk-hero-actions">
        <a class="ssdk-cta" href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>">Get a Quote</a>
        <a class="ssdk-cta ssdk-cta-ghost" href="tel:+971503605274">Call us: +971 50 360 5274</a>
      </div>
    </div>
    <div class="ssdk-hero-media">
      <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-hero.webp' ); ?>" alt="Dubai skyline with security systems" class="ssdk-hero-img" loading="lazy">
      <div class="ssdk-hero-iso">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/iso-badge.png' ); ?>" alt="ISO 9001:2015 certified" width="54" height="54" loading="lazy">
        <div><div>ISO 9001:2015</div><div>Quality-managed delivery</div></div>
      </div>
    </div>
  </div>
</section>

<!-- TRUST BAR -->
<section class="ssdk-trust">
  <div class="ssdk-container">
    <div class="ssdk-trust-inner">
      <div class="ssdk-trust-item">
        <span class="ssdk-trust-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m7 14 3-3 3 3 5-6"/></svg></span>
        <div><h3>Survey-led planning</h3><p>Every project starts with a site survey, risk assessment and written scope before anything is ordered.</p></div>
      </div>
      <div class="ssdk-trust-item">
        <span class="ssdk-trust-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6v6H9z"/><path d="M3 9h6M15 9h6M9 3v6M9 15v6"/></svg></span>
        <div><h3>Professional system design</h3><p>Engineered layouts, cabling schedules and device schedules reviewed with your team before installation.</p></div>
      </div>
      <div class="ssdk-trust-item">
        <span class="ssdk-trust-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg></span>
        <div><h3>Installation &amp; integration</h3><p>Certified technicians install, configure and integrate systems into your existing infrastructure.</p></div>
      </div>
      <div class="ssdk-trust-item">
        <span class="ssdk-trust-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg></span>
        <div><h3>Post-installation support</h3><p>Handover with training, documentation, and a support plan keeping systems running 24/7.</p></div>
      </div>
    </div>
    <div style="text-align:center;padding:10px 0 0"><a class="ssdk-cta" href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>">Why Work With Hutaib?</a></div>
  </div>
</section>

<!-- SERVICES -->
<section class="ssdk-section">
  <div class="ssdk-container">
    <div class="ssdk-section-head"><span class="ssdk-eyebrow">What we do</span><h2>One partner for every system your business relies on</h2><p>CCTV, access control, networking, meetings and telephony &mdash; engineered to work together, delivered on time, supported for years.</p></div>
    <div class="ssdk-services-grid">
      <div class="ssdk-service-card">
        <div class="ssdk-service-card-img"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-cctv.webp' ); ?>" alt="CCTV & Video Surveillance" loading="lazy"></div>
        <div class="ssdk-service-card-body"><div class="ssdk-service-num">01</div><h3>CCTV & Video Surveillance</h3><p>IP and analog CCTV, solar &amp; 4G connectivity cameras, AI-driven analytics and remote monitoring for any site.</p><a class="ssdk-service-link" href="<?php echo esc_url( home_url( '/services/cctv-security-surveillance/' ) ); ?>">Learn more</a></div>
      </div>
      <div class="ssdk-service-card">
        <div class="ssdk-service-card-img"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-access.webp' ); ?>" alt="Access Control & Door Systems" loading="lazy"></div>
        <div class="ssdk-service-card-body"><div class="ssdk-service-num">02</div><h3>Access Control &amp; Door Systems</h3><p>Biometric, card and mobile access, multi-door controllers, visitor management and full audit trails.</p><a class="ssdk-service-link" href="<?php echo esc_url( home_url( '/services/access-control-system/' ) ); ?>">Learn more</a></div>
      </div>
      <div class="ssdk-service-card">
        <div class="ssdk-service-card-img"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-network.webp' ); ?>" alt="Wireless & Networking" loading="lazy"></div>
        <div class="ssdk-service-card-body"><div class="ssdk-service-num">03</div><h3>Wireless &amp; Networking</h3><p>Structured cabling, Wi-Fi coverage, point-to-point links and secure ICT infrastructure.</p><a class="ssdk-service-link" href="<?php echo esc_url( home_url( '/services/wireless-solutions/' ) ); ?>">Learn more</a></div>
      </div>
      <div class="ssdk-service-card">
        <div class="ssdk-service-card-img"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-meeting.webp' ); ?>" alt="Meeting Rooms & PABX" loading="lazy"></div>
        <div class="ssdk-service-card-body"><div class="ssdk-service-num">04</div><h3>Meeting Rooms &amp; PABX</h3><p>Video conferencing, room control, PABX telephony and unified communications.</p><a class="ssdk-service-link" href="<?php echo esc_url( home_url( '/services/meeting-room-solutions/' ) ); ?>">Learn more</a></div>
      </div>
    </div>
    <div style="text-align:center"><a class="ssdk-cta-ghost" href="<?php echo esc_url( home_url( '/services/' ) ); ?>">Explore all services &rarr;</a></div>
  </div>
</section>

<!-- INDUSTRIES -->
<section class="ssdk-section ssdk-alt">
  <div class="ssdk-container">
    <div class="ssdk-section-head"><span class="ssdk-eyebrow">Industries we serve</span><h2>Security and connectivity for every sector</h2><p>One proven approach across the UAE&rsquo;s most demanding environments.</p></div>
    <div class="ssdk-industries-grid">
      <div class="ssdk-industry-cell">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-school.webp' ); ?>" alt="Education" class="ssdk-industry-card" loading="lazy">
        <div class="ssdk-industry-body"><h3>Education</h3><p>Secure campuses, classrooms and student data.</p></div>
      </div>
      <div class="ssdk-industry-cell">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-network.webp' ); ?>" alt="Telecommunication" class="ssdk-industry-card" loading="lazy">
        <div class="ssdk-industry-body"><h3>Telecommunication</h3><p>Uptime-critical networks and controlled access.</p></div>
      </div>
      <div class="ssdk-industry-cell">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-skyline.webp' ); ?>" alt="Smart Cities" class="ssdk-industry-card" loading="lazy">
        <div class="ssdk-industry-body"><h3>Smart Cities</h3><p>Public-space surveillance and infrastructure.</p></div>
      </div>
      <div class="ssdk-industry-cell">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-cctv.webp' ); ?>" alt="Healthcare" class="ssdk-industry-card" loading="lazy">
        <div class="ssdk-industry-body"><h3>Healthcare</h3><p>Protected facilities, records and equipment.</p></div>
      </div>
      <div class="ssdk-industry-cell">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-access.webp' ); ?>" alt="Government & Public Sector" class="ssdk-industry-card" loading="lazy">
        <div class="ssdk-industry-body"><h3>Government &amp; Public Sector</h3><p>Classified-grade security for public assets.</p></div>
      </div>
      <div class="ssdk-industry-cell">
        <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/photo-meeting.webp' ); ?>" alt="Commercial & Corporate" class="ssdk-industry-card" loading="lazy">
        <div class="ssdk-industry-body"><h3>Commercial &amp; Corporate</h3><p>Offices, retail and multi-site enterprises.</p></div>
      </div>
    </div>
  </div>
</section>

<!-- WHY HUTAIB -->
<section class="ssdk-section">
  <div class="ssdk-container">
    <div class="ssdk-section-head"><span class="ssdk-eyebrow">Why Hutaib</span><h2>Delivered with the discipline of a certified partner</h2></div>
    <div class="ssdk-why-grid">
      <div class="ssdk-why-card"><div class="ssdk-why-num">01</div><h3>ISO 9001:2015 Certified</h3><p>Quality-managed delivery: documented scope, controlled project records, tested handover.</p></div>
      <div class="ssdk-why-card"><div class="ssdk-why-num">02</div><h3>17+ Years in the UAE</h3><p>Local presence, local stock, local engineers &mdash; from Dubai to every emirate.</p></div>
      <div class="ssdk-why-card"><div class="ssdk-why-num">03</div><h3>500+ Projects Delivered</h3><p>From single-door offices to multi-site enterprise rollouts.</p></div>
      <div class="ssdk-why-card"><div class="ssdk-why-num">04</div><h3>24/7 Support &amp; Maintenance</h3><p>Real humans on call, rapid response, and preventive maintenance plans.</p></div>
    </div>
  </div>
</section>

<!-- PROCESS -->
<section class="ssdk-process">
  <div class="ssdk-container">
    <div class="ssdk-section-head"><span class="ssdk-eyebrow" style="background:rgba(255,255,255,.12);color:#FFD9A8">How it works</span><h2>From first survey to long-term support</h2></div>
    <div class="ssdk-process-track">
      <div class="ssdk-process-step"><span class="ssdk-process-ic"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#FFD9A8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m7 14 3-3 3 3 5-6"/></svg></span><h3>Site Survey</h3><p>On-site risk assessment, cabling survey and requirements workshop.</p></div>
      <div class="ssdk-process-step"><span class="ssdk-process-ic"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#FFD9A8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6v6H9z"/></svg></span><h3>System Design</h3><p>Engineered design, device schedule and budget &mdash; approved before installation.</p></div>
      <div class="ssdk-process-step"><span class="ssdk-process-ic"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#FFD9A8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg></span><h3>Installation &amp; Integration</h3><p>Certified technicians install, configure and integrate with your systems.</p></div>
      <div class="ssdk-process-step"><span class="ssdk-process-ic"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#FFD9A8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg></span><h3>Support &amp; Maintenance</h3><p>Training, documentation, 24/7 monitoring and preventive maintenance.</p></div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="ssdk-section">
  <div class="ssdk-container">
    <div class="ssdk-section-head"><span class="ssdk-eyebrow">Client feedback</span><h2>Trusted for the systems that cannot afford to fail</h2></div>
    <div class="ssdk-testimonials-slider">
      <div class="ssdk-testimonial" role="listitem">
        <p class="ssdk-testimonial-text">&ldquo;Very user-friendly Leave and Time Attendance Management Solutions. Their brilliant support team and quick turnover time make Employee Time Management most effective.&rdquo;</p>
        <div class="ssdk-testimonial-author"><span class="ssdk-testimonial-avatar">CT</span><div><div class="ssdk-testimonial-name">Ms. Catherine Pineda Tigas</div><div class="ssdk-testimonial-role">Time attendance &amp; HR systems</div></div></div>
      </div>
      <div class="ssdk-testimonial" role="listitem">
        <p class="ssdk-testimonial-text">&ldquo;Very good communication and fast in the response, trying the best to satisfy the customer. Providing the support and time flexibility according to our requirements.&rdquo;</p>
        <div class="ssdk-testimonial-author"><span class="ssdk-testimonial-avatar">IA</span><div><div class="ssdk-testimonial-name">Ishraq Alkhufash</div><div class="ssdk-testimonial-role">Client feedback</div></div></div>
      </div>
      <div class="ssdk-testimonial" role="listitem">
        <p class="ssdk-testimonial-text">&ldquo;Thanks a lot Hutaib. A very good service &mdash; we could deliver our critical project before timeline and our project manager was well informed on the proceedings.&rdquo;</p>
        <div class="ssdk-testimonial-author"><span class="ssdk-testimonial-avatar">S</span><div><div class="ssdk-testimonial-name">Siraj</div><div class="ssdk-testimonial-role">AqsaCom</div></div></div>
      </div>
      <div class="ssdk-testimonial" role="listitem">
        <p class="ssdk-testimonial-text">&ldquo;Good initiative. Keep rocking, as this will have a lot of advantage &mdash; educating the customer and building the brand. All the best.&rdquo;</p>
        <div class="ssdk-testimonial-author"><span class="ssdk-testimonial-avatar">SA</span><div><div class="ssdk-testimonial-name">Sathish Arya</div><div class="ssdk-testimonial-role">WatchNET International Trading LLC</div></div></div>
      </div>
      <div class="ssdk-testimonial-nav"><button type="button" class="ssdk-testimonial-btn" data-slide="prev" aria-label="Previous testimonial">&#8249;</button><button type="button" class="ssdk-testimonial-btn" data-slide="next" aria-label="Next testimonial">&#8250;</button></div>
    </div>
  </div>
</section>

<!-- PARTNERS -->
<section class="ssdk-section ssdk-partners">
  <div class="ssdk-container">
    <div class="ssdk-section-head"><span class="ssdk-eyebrow">Technology partners</span><h2>Integrated with the brands we trust</h2></div>
    <div class="ssdk-partner-grid">
      <div class="ssdk-partner">Avigilon</div>
      <div class="ssdk-partner">Mobotix</div>
      <div class="ssdk-partner">FingerTec</div>
      <div class="ssdk-partner">Evoko</div>
      <div class="ssdk-partner">Humly</div>
      <div class="ssdk-partner">Starlink</div>
      <div class="ssdk-partner">SANGFOR</div>
      <div class="ssdk-partner">Alcatel Lucent</div>
      <div class="ssdk-partner">CAMBIUM</div>
      <div class="ssdk-partner">CISCO</div>
      <div class="ssdk-partner">EATON</div>
      <div class="ssdk-partner">FORTINET</div>
      <div class="ssdk-partner">INFOSEC</div>
      <div class="ssdk-partner">NORDEN</div>
      <div class="ssdk-partner">VIRDI</div>
      <div class="ssdk-partner">WATCHNET</div>
      <div class="ssdk-partner">FUJITSU</div>
      <div class="ssdk-partner">Condeco</div>
      <div class="ssdk-partner">ATLAS.ti</div>
      <div class="ssdk-partner">ABB</div>
      <div class="ssdk-partner">Supermicro</div>
      <div class="ssdk-partner">ISS</div>
    </div>
  </div>
</section>

<!-- CLIENTS -->
<section class="ssdk-section">
  <div class="ssdk-container">
    <div class="ssdk-section-head"><span class="ssdk-eyebrow">Our clients</span><h2>Onsite across the region&rsquo;s leading organizations</h2></div>
    <div class="ssdk-clients-strip">
      <div class="ssdk-clients-track">
        <span class="ssdk-client-logo"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/client-deloitte.webp' ); ?>" alt="deloitte client logo" loading="lazy"></span>
        <span class="ssdk-client-logo"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/client-du.webp' ); ?>" alt="du client logo" loading="lazy"></span>
        <span class="ssdk-client-logo"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/client-comguard.webp' ); ?>" alt="comguard client logo" loading="lazy"></span>
        <span class="ssdk-client-logo"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/client-belleli.webp' ); ?>" alt="belleli client logo" loading="lazy"></span>
        <span class="ssdk-client-logo"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/client-mubadala.webp' ); ?>" alt="mubadala client logo" loading="lazy"></span>
        <span class="ssdk-client-logo"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/client-weatherford.webp' ); ?>" alt="weatherford client logo" loading="lazy"></span>
        <span class="ssdk-client-logo"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/client-arabtec.webp' ); ?>" alt="arabtec client logo" loading="lazy"></span>
        <span class="ssdk-client-logo"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/client-alnaboodah.webp' ); ?>" alt="alnaboodah client logo" loading="lazy"></span>
        <span class="ssdk-client-logo"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/client-alainhospital.webp' ); ?>" alt="alainhospital client logo" loading="lazy"></span>
        <span class="ssdk-client-logo"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/client-averda.webp' ); ?>" alt="averda client logo" loading="lazy"></span>
      </div>
    </div>
  </div>
</section>

<!-- BLOG PREVIEW -->
<section class="ssdk-section">
  <div class="ssdk-container">
    <div class="ssdk-section-head"><span class="ssdk-eyebrow">Insights</span><h2>Latest articles</h2><p>Practical guidance on security systems, networking and connectivity in the UAE.</p></div>
    <div class="ssdk-blog-preview-grid">
      <!-- Blog posts will show here if available -->
    </div>
    <div class="ssdk-blog-preview-all"><a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>">View all articles &rarr;</a></div>
  </div>
</section>

<!-- CTA BAND -->
<section class="ssdk-cta-band">
  <div class="ssdk-cta-band-inner">
    <div class="ssdk-container">
      <h2>Get your free security assessment</h2>
      <p>Tell us about your site and we will propose the right systems &mdash; with a fixed-price survey and no obligation.</p>
      <a class="ssdk-cta" href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>">Get a Quote</a>
    </div>
  </div>
</section>

</div>

<?php
get_footer();
